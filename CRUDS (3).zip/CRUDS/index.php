<?php
session_start();
include 'db.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Rediriger vers la page de login si l'utilisateur n'est pas connecté
    exit();
}

// Récupérer toutes les villes disponibles
$sqlVilles = "SELECT DISTINCT ville FROM users";
$stmtVilles = $pdo->prepare($sqlVilles);
$stmtVilles->execute();
$villes = $stmtVilles->fetchAll();

// Appliquer le filtre par ville si sélectionné
$villeFilter = '';
if (isset($_GET['ville'])) {
    $villeFilter = $_GET['ville'];
}

$sql = "SELECT * FROM users";
if ($villeFilter) {
    $sql .= " WHERE ville = ?";
}

$stmt = $pdo->prepare($sql);
if ($villeFilter) {
    $stmt->execute([$villeFilter]);
} else {
    $stmt->execute();
}

$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Utilisateurs</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            margin-bottom: 20px;
            text-align: center;
        }

        form select {
            padding: 10px;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
        }

        form input[type="submit"] {
            padding: 10px 15px;
            font-size: 1rem;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        form input[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #f2f2f2;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .action-buttons a {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 4px;
            color: #fff;
            font-size: 0.9rem;
        }

        .action-buttons .edit {
            background-color: #28a745;
        }

        .action-buttons .delete {
            background-color: #dc3545;
        }

        .action-buttons a:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Liste des utilisateurs</h2>

    <!-- Formulaire de tri par ville -->
    <form method="GET" action="index.php">
        <select name="ville">
            <option value="">-- Sélectionnez une ville --</option>
            <?php foreach ($villes as $ville): ?>
                <option value="<?php echo htmlspecialchars($ville['ville']); ?>" 
                        <?php echo $villeFilter === $ville['ville'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($ville['ville']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <input type="submit" value="Filtrer">
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Prénom</th>
                <th>ville</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['id']); ?></td>
                    <td><?php echo htmlspecialchars($user['name']); ?></td>
                    <td><?php echo htmlspecialchars($user['ville']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td>
                        <div class="action-buttons">
                            <a href="update.php?id=<?php echo htmlspecialchars($user['id']); ?>" class="edit">Edit</a>
                            <a href="delete.php?id=<?php echo htmlspecialchars($user['id']); ?>" class="delete">Delete</a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>