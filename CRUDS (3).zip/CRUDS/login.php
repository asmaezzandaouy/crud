<style>
    /* Style général du corps de la page */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f0f2f5;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    color: #333;
    background: url('https://i.pinimg.com/474x/76/2c/ed/762ced66ac12d319660159d37dd29eee.jpg');
}

/* Style du formulaire */
form {
    background-color: white;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    width: 350px;
    text-align: center;
    border: 1px solid #ccc;
}

/* Style des labels */
form label {
    display: block;
    margin-bottom: 8px;
    font-size: 14px;
    color: #555;
}

/* Style des champs de formulaire (inputs) */
form input[type="email"],
form input[type="password"] {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
    box-sizing: border-box;
    transition: border-color 0.3s ease;
}

/* Focus sur les champs */
form input[type="email"]:focus,
form input[type="password"]:focus {
    border-color: #1E90FF; /* Bleu clair */
    outline: none;
}

/* Style du bouton de soumission */
form input[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: #1E90FF; /* Bleu */
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

/* Effet de survol sur le bouton de soumission */
form input[type="submit"]:hover {
    background-color: #4682B4; /* Bleu plus foncé */
}

/* Style des messages d'erreur */
form .error {
    color: red;
    font-size: 14px;
    margin-top: 10px;
}

/* Style de la page en cas de connexion réussie */
h2 {
    color: #1E90FF; /* Bleu */
    text-align: center;
}

/* Responsive: améliore l'affichage sur petits écrans */
@media (max-width: 600px) {
    form {
        width: 90%;
    }
}

</style>
<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        header("Location: index.php"); // Rediriger vers la page d'accueil
        exit();
    } else {
        echo "Identifiants incorrects.";
    }
}
?>

<form method="POST" action="login.php">
    Email: <input type="email" name="email" required><br>
    Mot de passe: <input type="password" name="password" required><br>
    <input type="submit" value="Se connecter">
</form>
