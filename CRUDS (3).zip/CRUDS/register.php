<style>
    /* Style général du corps de la page */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    background: url('https://i.pinimg.com/474x/76/2c/ed/762ced66ac12d319660159d37dd29eee.jpg');
    color: #333;
}

/* Style du formulaire d'inscription */
form {
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    width: 350px;
    text-align: center;
    border: 1px solid #ddd;
}

/* Style des labels */
form label {
    display: block;
    margin-bottom: 8px;
    font-size: 14px;
    color: #555;
}

/* Style des champs de formulaire (inputs) */
form input[type="text"],
form input[type="email"],
form input[type="password"],
form input[type="number"] {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    box-sizing: border-box;
    transition: border-color 0.3s ease;
}

/* Focus sur les champs de formulaire */
form input[type="text"]:focus,
form input[type="email"]:focus,
form input[type="password"]:focus,
form input[type="number"]:focus {
    border-color: #4CAF50;
    outline: none;
}

/* Style du bouton de soumission */
form input[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

/* Effet de survol sur le bouton de soumission */
form input[type="submit"]:hover {
    background-color: #45a049;
}

/* Style des messages d'erreur */
form .error {
    color: red;
    font-size: 14px;
    margin-top: 10px;
}

/* Style de la page d'inscription réussie */
h2 {
    color: #4CAF50;
    text-align: center;
    font-size: 24px;
}

/* Responsive: améliore l'affichage sur petits écrans */
@media (max-width: 600px) {
    form {
        width: 90%;
    }
}

</style>
<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $age = $_POST['age'];
    $ville = $_POST['ville'];

    $sql = "INSERT INTO users (name, email, password, age, ville) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$name, $email, $password, $age, $ville]);

    echo "Inscription réussie ! Vous pouvez maintenant vous connecter.";
}
?>

<form method="POST" action="register.php">
    Nom: <input type="text" name="name" required><br>
    
    Email: <input type="email" name="email" required><br>
    Mot de passe: <input type="password" name="password" required><br>
    Age: <input type="number" name="age" required><br>
    Ville: <input type="text" name="ville" required><br>
    <input type="submit" value="S'inscrire">
</form>
