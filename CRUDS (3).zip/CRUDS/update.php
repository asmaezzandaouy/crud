<?php
include 'db.php';

// Si la méthode de requête est POST (lorsque le formulaire est soumis)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données envoyées par le formulaire
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $ville = $_POST['ville'];

    // Valider que tous les champs sont remplis
    if (empty($name) || empty($email) || empty($age) || empty($ville)) {
        echo "Tous les champs doivent être remplis.";
        exit();
    }

    // Requête SQL pour mettre à jour l'utilisateur
    $sql = "UPDATE users SET name = ?, email = ?, age = ?, ville = ? WHERE id = ?";
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([$name, $email, $age, $ville, $id]);
        echo "Utilisateur mis à jour avec succès !";
    } catch (PDOException $e) {
        echo "Erreur: " . $e->getMessage();  // Afficher l'erreur si la mise à jour échoue
    }
}

// Si l'ID est passé dans l'URL, afficher les données de l'utilisateur pour la modification
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Requête SQL pour récupérer les informations de l'utilisateur à mettre à jour
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $user = $stmt->fetch();

    // Vérifier si l'utilisateur existe
    if (!$user) {
        echo "Utilisateur introuvable.";
        exit();
    }
} else {
    echo "Aucun ID spécifié pour la mise à jour.";
    exit();
}
?>

<!-- Formulaire de mise à jour des informations utilisateur -->
<form method="POST" action="update.php">
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">

    <label for="name">Nom:</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required><br>

    <label for="email">Email:</label>
    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required><br>

    <label for="age">Age:</label>
    <input type="number" name="age" value="<?php echo htmlspecialchars($user['age']); ?>" required><br>

    <label for="ville">Ville:</label>
    <input type="text" name="ville" value="<?php echo htmlspecialchars($user['ville']); ?>" required><br>

    <input type="submit" value="Mettre à jour">
</form>
