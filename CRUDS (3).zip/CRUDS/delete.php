<?php
include 'db.php';

// Vérifier si l'ID est passé dans l'URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Vérifier si l'utilisateur existe dans la base de données
    $sql_check = "SELECT * FROM users WHERE id = ?";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([$id]);
    $user = $stmt_check->fetch();

    // Si l'utilisateur existe, procéder à la suppression
    if ($user) {
        try {
            // Requête de suppression
            $sql = "DELETE FROM users WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$id]);

            echo "Utilisateur supprimé avec succès !";
        } catch (PDOException $e) {
            echo "Erreur: " . $e->getMessage();  // Gérer les erreurs SQL
        }
    } else {
        echo "Aucun utilisateur trouvé avec cet ID.";  // Si l'utilisateur n'existe pas
    }
} else {
    echo "ID manquant dans l'URL.";  // Si l'ID n'est pas passé dans l'URL
}
?>
